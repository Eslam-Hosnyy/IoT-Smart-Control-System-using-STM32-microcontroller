/************************************/
/*	Author		: ESLAM_HOSNY		*/
/*	SWC			: ESP8266		 	*/
/*	Layer		: HAL				*/
/*	Version   	: 1.0				*/
/*	Date	  	: October 23, 2022	*/
/*	Last Edit 	: N/A				*/
/************************************/
#include "LSTD_types.h"
#include "LBIT_math.h"
#include "MUSART_interface.h"
#include "MSTICK_interface.h"
#include "HESP_private.h"
#include "HESP_interface.h"
#include "HCLCD_interface.h"

static char		   *Glo_charData = 0;
static volatile u8 Glo_u8State	 = 0;
static volatile u8 Validation	 = 0;
static volatile u8 Glo_u8Busy	 = 0;
volatile		u8 Glo_u8OK		 = 0;
volatile		u8 Glo_u8ValBusy = 0;

void HESP_voidInit(void)
{
	Validation  = 0;
	Glo_u8State = 0;

	do
	{
		MUSART_voidTransimitSynch("ATE0\r\n");
		Glo_u8State = HESP_u8Validation();
	}while( (1 != Glo_u8State) );

	Glo_u8State = 0;
	do
	{
		MUSART_voidTransimitSynch("AT\r\n");
		Glo_u8State = HESP_u8Validation();
	}while( (1 != Glo_u8State) );

	Glo_u8State = 0;
	do
	{
		MUSART_voidTransimitSynch("AT+CWMODE=3\r\n");
		Glo_u8State = HESP_u8Validation();
	}while( (1 != Glo_u8State) );
}

void HESP_voidConnectToNetWork(char *Ptr_charUser, char *Ptr_charPass)
{
	char Loc_charSendData[50]="AT+CWJAP=\"";
	Concatenate(Loc_charSendData, Ptr_charUser, "\",\"");
	Concatenate(Loc_charSendData, Ptr_charPass, "\"\r\n");

	Glo_u8State = 0;
	do
	{
		Validation  = 0;

		MUSART_voidTransimitSynch(Loc_charSendData);
		Glo_u8State = HESP_u8Validation();
	}while( (1 != Glo_u8State) );
}


void HESP_voidConnectToServer(char *Ptr_CharConnType, char *Ptr_charIP,char *Ptr_chaPort)
{
	char Loc_charSendData[50]="AT+CIPSTART=\"";

	if( 0 == Glo_u8Busy)
	{
		Glo_u8Busy = 1;
		Concatenate(Loc_charSendData, Ptr_CharConnType, "\",\"");
		Concatenate(Loc_charSendData, Ptr_charIP, "\",");
		Concatenate(Loc_charSendData, Ptr_chaPort, "\r\n");

		Glo_u8State	= 0;
		do
		{
			Validation  = 0;

			MUSART_voidTransimitSynch(Loc_charSendData);
			Glo_u8State = HESP_u8Validation();

		}while( (1 != Glo_u8State) );
	}
}

void HESP_voidSendLength(char *ptr_charLinkLength)
{
	char Loc_charSendData[50]="AT+CIPSEND=";

	if( 1 == Glo_u8Busy)
	{
		Concatenate(Loc_charSendData, ptr_charLinkLength, "\r\n");

		Glo_u8State = 0;
		do
		{
			Validation  = 0;

			MUSART_voidTransimitSynch(Loc_charSendData);
			Glo_u8State = HESP_u8Validation();

		}while( (1 != Glo_u8State) );
	}
}

void HESP_u8GetDataLink(char *ptr_charLink, char *ptr_charReturnedData)
{
	volatile u8 Loc_u8I = 0;
	char Loc_charSendData[80]="GET ";

	if( 1 == Glo_u8Busy)
	{
		ptr_charReturnedData[0] = 0;
		Concatenate(Loc_charSendData, ptr_charLink, "\r\n");

		do
		{
			Validation		= 1;
			Glo_u8State		= 0;

			MUSART_voidTransimitSynch(Loc_charSendData);
			Glo_u8State = HESP_u8Validation();
		}while( (1 != Glo_u8State) );

		if(1 == Glo_u8OK)
		{
			Glo_u8OK = 0;
			for(Loc_u8I = 21; 'C'!=Glo_charData[Loc_u8I]; Loc_u8I++)
			{
				ptr_charReturnedData[Loc_u8I - 21] = Glo_charData[Loc_u8I];
			}
		}

		Glo_u8Busy = 0;
	}
}



static u8 HESP_u8Validation(void)
{
	if(0==Glo_u8ValBusy)
	{
		Glo_u8ValBusy = 1;
		volatile u16  Loc_u8Itera		= 0;
		static   char Loc_charData[500]	= {0};

		if(0 == Validation)
			MUSART_voidReceiveSynch(Loc_charData,'K');
		if(1 == Validation)
			MUSART_voidReceiveSynch(Loc_charData,'D');

		for(Loc_u8Itera=0; Loc_charData[Loc_u8Itera]!='\0'; Loc_u8Itera++)
		{
			if( (0==Validation)&&( (Loc_charData[Loc_u8Itera]=='O')&&(Loc_charData[1+Loc_u8Itera]=='K')))
			{
				Glo_u8State = 1;
				break;
			}
			else if( (0==Validation)&&( (Loc_charData[Loc_u8Itera]=='C')&&(Loc_charData[1+Loc_u8Itera]=='O')&&(Loc_charData[2+Loc_u8Itera]=='N'&&(Loc_charData[11+Loc_u8Itera]=='O')&&(Loc_charData[12+Loc_u8Itera]=='K'))) )
			{
				Glo_u8State = 1;
				break;
			}
			else if( ( (Loc_charData[Loc_u8Itera]=='A')&&(Loc_charData[1+Loc_u8Itera]=='L')&&(Loc_charData[2+Loc_u8Itera]=='R'&&(Loc_charData[3+Loc_u8Itera]=='E')&&(Loc_charData[4+Loc_u8Itera]=='A'))) )
			{
				Glo_u8State = 1;
				Glo_u8OK = 0;
				break;
			}
			else if( (1==Validation)&&( (Loc_charData[Loc_u8Itera]=='I')&&(Loc_charData[1+Loc_u8Itera]=='P')&&(Loc_charData[2+Loc_u8Itera]=='D')) )
			{
				if( ( (Loc_charData[3+Loc_u8Itera]==',')&&(Loc_charData[5+Loc_u8Itera]==':')) )
				{
					Glo_charData = Loc_charData;
					Glo_u8State = 1;
					Glo_u8OK	= 1;
					break;
				}
				else
				{
					Glo_u8OK = 0;
					Glo_u8State = 1;
					break;
				}
			}
			else if( ( (Loc_charData[Loc_u8Itera]=='0')&&(Loc_charData[1+Loc_u8Itera]==',')&&(Loc_charData[2+Loc_u8Itera]=='C'&&(Loc_charData[3+Loc_u8Itera]=='L')&&(Loc_charData[4+Loc_u8Itera]=='O')&&(Loc_charData[5+Loc_u8Itera]=='S'))) )
			{
				Glo_u8State = 1;
				Glo_u8OK = 0;
				break;
			}
			else if( (1==Validation)&&( (Loc_charData[Loc_u8Itera]=='.')&&(Loc_charData[1+Loc_u8Itera]=='.')&&(Loc_charData[2+Loc_u8Itera]=='.')) )
			{
				Glo_u8State = 1;
				Glo_u8OK = 0;
				break;
			}
			else if( (1==Validation)&&( (Loc_charData[Loc_u8Itera]=='H')&&(Loc_charData[1+Loc_u8Itera]=='T')&&(Loc_charData[2+Loc_u8Itera]=='T')&&(Loc_charData[3+Loc_u8Itera]=='P')&&(Loc_charData[4+Loc_u8Itera]=='/')) )
			{
				Glo_u8State = 1;
				Glo_u8OK = 0;
				break;
			}
			else if( (1==Validation)&&( (Loc_charData[Loc_u8Itera]=='\r')&&(Loc_charData[1+Loc_u8Itera]=='\n')&&(Loc_charData[2+Loc_u8Itera]=='C')&&(Loc_charData[3+Loc_u8Itera]=='L')&&(Loc_charData[4+Loc_u8Itera]=='O')) )
			{
				Glo_u8State = 1;
				Glo_u8OK = 0;
				break;
			}
			else if( ( (Loc_charData[Loc_u8Itera]=='R')&&(Loc_charData[1+Loc_u8Itera]=='O')&&(Loc_charData[2+Loc_u8Itera]=='R')) )
			{
				Glo_u8State = 0;
				Glo_u8OK = 0;
				break;
			}
			else
			{
				Glo_u8OK = 0;
				Glo_u8State = 0;
			}

		}

		Glo_u8ValBusy = 0;
	}
	return Glo_u8State;
}

static void Concatenate(char *S1, char *S2, char *S3)
{
	volatile u8 Loc_u8I = 0, Loc_u8Len = 0;

	while('\0' != S1[Loc_u8Len])
	{
		Loc_u8Len++;
	}

	for(Loc_u8I=0; '\0' != S2[Loc_u8I]; ++Loc_u8I,++Loc_u8Len)
	{
		S1[Loc_u8Len] = S2[Loc_u8I];
	}
	S1[Loc_u8Len] = '\0';

	while('\0' != S1[Loc_u8Len])
	{
		Loc_u8Len++;
	}

	for(Loc_u8I=0; '\0' != S3[Loc_u8I]; ++Loc_u8I,++Loc_u8Len)
	{
		S1[Loc_u8Len] = S3[Loc_u8I];
	}

	S1[Loc_u8Len] = '\0';
}

