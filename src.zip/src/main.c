/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: ESP8266     				*/
/*	Layer		: APP					*/
/*	Version   	: 1.0					*/
/*	Date	  	: N/A					*/
/*	Last Edit 	: N/A					*/
/****************************************/
#include "LSTD_types.h"
#include "LBIT_math.h"
#include "MRCC_interface.h"
#include "MUSART_interface.h"
#include "MSTICK_interface.h"
#include "MDIO_interface.h"
#include "MINVIC_interface.h"
#include "HCLCD_interface.h"
#include "HESP_interface.h"


int main(void)
{
	MRCC_voidInitSystemClock();
	MRCC_voidEnablePrephiralClock(MRCC_APB2_BUS, 2);
	MRCC_voidEnablePrephiralClock(MRCC_APB2_BUS, 3);
	MRCC_voidEnablePrephiralClock(MRCC_APB2_BUS, 14);

	MINVIC_voidInit();

	MSTICK_voidInit();

	MDIO_voidSetPinMode(MDIOA, PIN9, OUTPUT_AFPP_50MHZ);
	MDIO_voidSetPinMode(MDIOA, PIN10, INPUT_FLOATING);
	MDIO_voidSetPinMode(MDIOB, PIN0, OUTPUT_PP_2MHZ);

	MDIO_voidSetPinMode(MDIOB, PIN4, OUTPUT_PP_2MHZ);
	MDIO_voidSetPinMode(MDIOB, PIN5, OUTPUT_PP_2MHZ);
	MDIO_voidSetPinMode(MDIOB, PIN6, OUTPUT_PP_2MHZ);
	MDIO_voidSetPinMode(MDIOB, PIN7, OUTPUT_PP_2MHZ);



	MUSART_voidInit(MUSART_DATABITS_8, MUSART_STOPBITS_1, MUSART_NO_PARITY, MUSART_BAUD_RATE_115200);
	MUSART_voidEnable();

	MUSART_voidTransimitASynch("Hi I'm ESLAM HOSNY, I'm Embedded Engineer ^_^!");
	MUSART_voidTransimitASynch("Hi I'm ");
	MUSART_voidTransimitASynch("Hi I'm ESLAM");
	MUSART_voidTransimitASynch("Hi I'm ESLAM HOSNY");

	MINVIC_voidEnableInterrupt(37);

/*
	CLCD_voidInit();
	CLCD_voidClear();

	CLCD_voidSendStringXY(0, 2, "Smart Control");

	CLCD_voidClear();

	HESP_voidInit();
	CLCD_voidSendStringXY(0, 0, "START");
	HESP_voidConnectToNetWork("HOT","ES011ESS");
	CLCD_voidSendStringXY(0, 7, "CONNECTED");
	CLCD_voidSendStringXY(1, 0, "Data is : ");

*/
	while(1)
	{


/*		HESP_voidConnectToServer("TCP","23.179.32.36","80");
		HESP_voidSendLength("48");
		HESP_u8GetDataLink("http://smartsys97x.orgfree.com/Alldata.txt",Data);

		CLCD_voidSendStringXY(1, 10, Data);

		for(u8 i=0;i<4;i++)
		{
			if(Data[i]=='1')
				MDIO_voidBSRR_Set_Clear_Pin(MDIOB, i+4, 1);
			else
				MDIO_voidBSRR_Set_Clear_Pin(MDIOB, i+4, 0);

		}*/

	}

	return 0;

}



