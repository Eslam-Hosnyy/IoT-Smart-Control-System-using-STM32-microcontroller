/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: RCC     				*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#include "LSTD_types.h"
#include "LBIT_math.h"
#include "MRCC_config.h"
#include "MRCC_private.h"
#include "MRCC_interface.h"

void MRCC_voidInitSystemClock(void)
{
#if MRCC_SYSTEM_CLCK == MRCC_HSE_CRYSTAL
	RCC_CR	 = 0x00010000;
	RCC_CFGR = 0x00000001;
#elif MRCC_SYSTEM_CLCK == MRCC_HSE_RC
	RCC_CR	 = 0x00050000;
	RCC_CFGR = 0x00000001;
#elif MRCC_SYSTEM_CLCK == MRCC_HSI
	RCC_CR	 = 0x00000081;
	RCC_CFGR = 0x00000000;
#elif MRCC_SYSTEM_CLCK == MRCC_PLL
	RCC_CR	 = 0x01000000;
#if PLL_INPUT_SOURCE == MRCC_PLL_HSE
#if PLL_MUL_FACTOR == 2
	RCC_CFGR = 0x00010002;
#elif PLL_MUL_FACTOR == 3
	RCC_CFGR = 0x00050002;
#elif PLL_MUL_FACTOR == 4
	RCC_CFGR = 0x00090002;
#elif PLL_MUL_FACTOR == 5
	RCC_CFGR = 0x000C0002;
#elif PLL_MUL_FACTOR == 6
	RCC_CFGR = 0x00110002;
#elif PLL_MUL_FACTOR == 7
	RCC_CFGR = 0x00150002;
#elif PLL_MUL_FACTOR == 8
	RCC_CFGR = 0x00190002;
#elif PLL_MUL_FACTOR == 9
	RCC_CFGR = 0x001C0002;
#elif PLL_MUL_FACTOR == 10
	RCC_CFGR = 0x00210002;
#elif PLL_MUL_FACTOR == 11
	RCC_CFGR = 0x00250002;
#elif PLL_MUL_FACTOR == 12
	RCC_CFGR = 0x00290002;
#elif PLL_MUL_FACTOR == 13
	RCC_CFGR = 0x002C0002;
#elif PLL_MUL_FACTOR == 14
	RCC_CFGR = 0x00310002;
#elif PLL_MUL_FACTOR == 15
	RCC_CFGR = 0x00350002;
#elif PLL_MUL_FACTOR == 16
	RCC_CFGR = 0x00390002;
#else
#error ("ERROR")
#endif
#elif PLL_INPUT_SOURCE == MRCC_PLL_HSE_DIV_2
#if PLL_MUL_FACTOR == 2
	RCC_CFGR = 0x00020002;
#elif PLL_MUL_FACTOR == 3
	RCC_CFGR = 0x00060002;
#elif PLL_MUL_FACTOR == 4
	RCC_CFGR = 0x000A0002;
#elif PLL_MUL_FACTOR == 5
	RCC_CFGR = 0x000E0002;
#elif PLL_MUL_FACTOR == 6
	RCC_CFGR = 0x00120002;
#elif PLL_MUL_FACTOR == 7
	RCC_CFGR = 0x00160002;
#elif PLL_MUL_FACTOR == 8
	RCC_CFGR = 0x001A0002;
#elif PLL_MUL_FACTOR == 9
	RCC_CFGR = 0x001E0002;
#elif PLL_MUL_FACTOR == 10
	RCC_CFGR = 0x00220002;
#elif PLL_MUL_FACTOR == 11
	RCC_CFGR = 0x00260002;
#elif PLL_MUL_FACTOR == 12
	RCC_CFGR = 0x002A0002;
#elif PLL_MUL_FACTOR == 13
	RCC_CFGR = 0x002E0002;
#elif PLL_MUL_FACTOR == 14
	RCC_CFGR = 0x00320002;
#elif PLL_MUL_FACTOR == 15
	RCC_CFGR = 0x00360002;
#elif PLL_MUL_FACTOR == 16
	RCC_CFGR = 0x003A0002;
#else
#error ("ERROR")
#endif
#elif PLL_INPUT_SOURCE == MRCC_PLL_HSI_DIV_2
#if PLL_MUL_FACTOR == 2
	RCC_CFGR = 0x00000002;
#elif PLL_MUL_FACTOR == 3
	RCC_CFGR = 0x00040002;
#elif PLL_MUL_FACTOR == 4
	RCC_CFGR = 0x00080002;
#elif PLL_MUL_FACTOR == 5
	RCC_CFGR = 0x000B0002;
#elif PLL_MUL_FACTOR == 6
	RCC_CFGR = 0x00100002;
#elif PLL_MUL_FACTOR == 7
	RCC_CFGR = 0x00140002;
#elif PLL_MUL_FACTOR == 8
	RCC_CFGR = 0x00180002;
#elif PLL_MUL_FACTOR == 9
	RCC_CFGR = 0x001B0002;
#elif PLL_MUL_FACTOR == 10
	RCC_CFGR = 0x00200002;
#elif PLL_MUL_FACTOR == 11
	RCC_CFGR = 0x00240002;
#elif PLL_MUL_FACTOR == 12
	RCC_CFGR = 0x00280002;
#elif PLL_MUL_FACTOR == 13
	RCC_CFGR = 0x002B0002;
#elif PLL_MUL_FACTOR == 14
	RCC_CFGR = 0x00300002;
#elif PLL_MUL_FACTOR == 15
	RCC_CFGR = 0x00340002;
#elif PLL_MUL_FACTOR == 16
	RCC_CFGR = 0x00380002;

#else
#error ("ERROR")
#endif
#endif

#else
#error ("ERROR")
#endif




}

void MRCC_voidEnablePrephiralClock(u8 Copy_u8Bus, u8 Copy_u8PrephiralId)
{

	if(31>=Copy_u8PrephiralId)
	{
		switch (Copy_u8Bus)
		{
		case MRCC_AHB_BUS :	SET_BIT(RCC_AHBENR, Copy_u8PrephiralId);	break;
		case MRCC_APB1_BUS:	SET_BIT(RCC_APB1ENR, Copy_u8PrephiralId);	break;
		case MRCC_APB2_BUS:	SET_BIT(RCC_APB2ENR, Copy_u8PrephiralId);	break;
		default : /*error*/ break;
		}
	}
	else
	{
		//error
	}
}

void MRCC_voidDisablePrephiralClock(u8 Copy_u8Bus, u8 Copy_u8PrephiralId)
{
	if(31>=Copy_u8PrephiralId)
	{
		switch (Copy_u8Bus)
		{
		case MRCC_AHB_BUS :	CLEAR_BIT(RCC_AHBENR, Copy_u8PrephiralId);	break;
		case MRCC_APB1_BUS:	CLEAR_BIT(RCC_APB1ENR, Copy_u8PrephiralId);	break;
		case MRCC_APB2_BUS:	CLEAR_BIT(RCC_APB2ENR, Copy_u8PrephiralId);	break;
		default : /*error*/ break;
		}
	}
	else
	{
		//error
	}
}

