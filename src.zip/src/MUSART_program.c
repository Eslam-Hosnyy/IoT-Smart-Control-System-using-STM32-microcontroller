/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: USART    				*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#include "LSTD_types.h"
#include "LBIT_math.h"
#include "MSTICK_interface.h"
#include "MUSART_config.h"
#include "MUSART_private.h"
#include "MUSART_interface.h"
#include "HCLCD_interface.h"

static volatile u8 Glo_u8TimeFlag0;
static volatile u8 Glo_u8TimeFlag1;
static volatile u8 Glo_u8TimeFlag2;

volatile char *Ptr_charGlo_TXData = NULL;
volatile char *Ptr_charGlo_RXData = NULL;

volatile u8 Glo_u8Rx_count = 0;
volatile u8 Glo_u8Tx_count = 0;

void MUSART_voidInit(u8 Copy_u8DataSize, u8 Copy_u8StopBits, u8 Copy_u8Parity, u32 Copy_u32BaudRate)
{
	u16 Loc_u16BRR_Mantissa = 0;
	u8	Loc_u8BRR_Fraction  = 0;
	f16 Loc_f16Divider		= 0;

	Loc_f16Divider 		= ( ((f16)MUSART_SYSTEM_CLOCK*1.00)/(Copy_u32BaudRate*16.00) );
	Loc_u16BRR_Mantissa = (u16)Loc_f16Divider;
	Loc_u8BRR_Fraction  = (u8)( (f16)(Loc_f16Divider - Loc_u16BRR_Mantissa)*16.00 );

	MUSART->CR1 = 0;
	MUSART->BBR = 0;
	MUSART->CR1 |= Copy_u8DataSize<<12;
	MUSART->CR2 |= Copy_u8StopBits<<12;
	MUSART->CR1 |= Copy_u8Parity<<9;
	MUSART->BBR |= (Loc_u16BRR_Mantissa<<4) | (Loc_u8BRR_Fraction);
	SET_BIT(MUSART->CR1, 3);
	SET_BIT(MUSART->CR1, 2);

	MUSART->SR = 0;

	SET_BIT(MUSART->CR1,5);

	SET_BIT(MUSART->CR1,7);
}

void MUSART_voidEnable(void)
{
	SET_BIT(MUSART->CR1, 13);
}

void MUSART_voidDisable(void)
{
	CLEAR_BIT(MUSART->CR1, 13);
}

void MUSART_voidTransimitSynch(const char *Copy_charData)
{
	u16 Loc_u16Bit = 0;
	Glo_u8TimeFlag0 = 0;
	MUSART->DR = 0;

	while('\0' != Copy_charData[Loc_u16Bit])
	{
		MUSART->DR = Copy_charData[Loc_u16Bit++];
		while( !GET_BIT(MUSART->SR, 6) )
		{
			MSTICK_voidIntervalPeriodic(1000,MUSART_voidBrake);
			if(1 == Glo_u8TimeFlag0)
				break;
		}
	}

}


void MUSART_voidReceiveSynch(char *ptr_charRecievedData, char Copy_charTreminator )
{
	u16 Loc_u16Bit			= 0;
	Glo_u8TimeFlag1			= 0;
	*ptr_charRecievedData	= 0;
	static char *Check		= 0;

	if('D' == Copy_charTreminator)
	{
		Check = ".DD";
		Copy_charTreminator = '\r';
	}
	else if('K' == Copy_charTreminator)
	{
		Check = "KRL";
		Copy_charTreminator = '\r';
	}
	else
	{

	}

	do
	{
		while( !GET_BIT(MUSART->SR, 5) )
		{
			MSTICK_voidIntervalPeriodic(1000,MUSART_voidBrake);
			if(1 == Glo_u8TimeFlag1)
				break;
		}
		if(1 == Glo_u8TimeFlag1)
		{
			ptr_charRecievedData[Loc_u16Bit++] = 128;
			break;
		}
		else
		{
			ptr_charRecievedData[Loc_u16Bit++] = MUSART->DR;
		}

	}while((Copy_charTreminator!=ptr_charRecievedData[Loc_u16Bit - 1])||((Check[0]!=ptr_charRecievedData[Loc_u16Bit - 2])&&(Check[1]!=ptr_charRecievedData[Loc_u16Bit - 2])&&(Check[2]!=ptr_charRecievedData[Loc_u16Bit - 2])) );

}


static void MUSART_voidBrake(void)
{
	if(0 == Glo_u8TimeFlag0)
	{
		Glo_u8TimeFlag0 = 1;
	}
	else
	{
		Glo_u8TimeFlag0 = 0;
	}

	if(0 == Glo_u8TimeFlag1)
	{
		Glo_u8TimeFlag1 = 1;
	}
	else
	{
		Glo_u8TimeFlag1 = 0;
	}

	if(0 == Glo_u8TimeFlag2)
	{
		Glo_u8TimeFlag2 = 1;
	}
	else
	{
		Glo_u8TimeFlag2 = 0;
	}

}


void MUSART_voidTransimitASynch(char *Ptr_charTxData)
{
	Ptr_charGlo_TXData = Ptr_charTxData;
}

void MUSART_voidReceiveASynch(char *Ptr_charRxData)
{
	Ptr_charGlo_RXData = Ptr_charRxData;
}


void USART1_IRQHandler(void)
{
	// if receive buffer ready to read
	if( GET_BIT(MUSART->SR, 5) )
	{
		// move byte from buffer to message
		if( '\0' != Ptr_charGlo_RXData[Glo_u8Rx_count] )
		{
			Ptr_charGlo_RXData[Glo_u8Rx_count] = MUSART->DR & 0x0FF; // reading RDR clears RXNE flag
			Glo_u8Rx_count++;
		}
/*		else if( '\0' == Ptr_charGlo_RXData[Glo_u8Rx_count] )
		{
			Glo_u8Rx_count = 0;
		}
		else
		{

		}*/

	}

	// if byte ready to transfer
	if( GET_BIT(MUSART->SR, 6) )
	{
		// send  byte to TDR
		if( '\0' != Ptr_charGlo_TXData[Glo_u8Tx_count] )
		{
			MUSART->DR = Ptr_charGlo_TXData[Glo_u8Tx_count]; // write to TDR (clears TC bit)
			Glo_u8Tx_count++;
		}
/*		else if( '\0' == Ptr_charGlo_TXData[Glo_u8Tx_count] )
		{
			Glo_u8Tx_count = 0;
		}
		else
		{

		}*/

	}

}

