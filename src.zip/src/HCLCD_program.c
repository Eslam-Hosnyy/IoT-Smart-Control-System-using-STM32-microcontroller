/************************************/
/*	Author		: ESLAM_HOSNY		*/
/*	SWC			: CLCD		 		*/
/*	Layer		: HAL				*/
/*	Version   	: 1.0				*/
/*	Date	  	: October 23, 2022	*/
/*	Last Edit 	: N/A				*/
/************************************/
#include "LSTD_types.h"
#include "LBIT_math.h"
#include "MSTICK_interface.h"
#include "MDIO_interface.h"
#include "HCLCD_config.h"
#include "HCLCD_interface.h"

void CLCD_voidInit(void)
{
	MDIO_voidSetPortMode(CLCD_DATAPORT, LSB_Signfication, OUTPUT_PP_2MHZ);
	MDIO_voidSetPortMode(CLCD_CTRLPORT, LSB_Signfication, OUTPUT_PP_2MHZ);

	/* Wait for more 30ms */
	MSTICK_voidInit();
	MSTICK_voidBusyWait(40);

#if CLCD_MODE==0
	/* Function Set Command: 2 lines, 5*8 Font_Size */
	CLCD_voidSendCommand(0x38);

	/* Function ON OFF Control: Display enable, Disable_Curser, No_Blink */
	CLCD_voidSendCommand(0x0C);

	/* Clear Display */
	CLCD_voidSendCommand(0x01);

#elif CLCD_MODE==1
	/* Function Set Command: 2 lines, 5*8 Font_Size */
	CLCD_voidSendCommand(0x02);
	CLCD_voidSendCommand(0x28);

	/* Function ON OFF Control: Display enable, Disable_Curser, No_Blink */
	CLCD_voidSendCommand(0x0C);

	/* Clear Display */
	CLCD_voidSendCommand(0x06);
	CLCD_voidSendCommand(0x83);

	MSTICK_voidBusyWait(4);

#endif

}

void CLCD_voidClear(void)
{
	CLCD_voidSendCommand(0x01);
	CLCD_voidSendCommand(0x80);
}

void CLCD_voidCurserEnable(void)
{
	CLCD_voidSendCommand(0x0F);

}
void CLCD_voidGoToXY(u8 ARG_Y, u8 ARG_X)
{
	u8 L_u8Address=0;

	if(0 == ARG_Y)
	{
		L_u8Address = ARG_X;
	}
	else if (1 == ARG_Y)
	{
		L_u8Address = (ARG_X+0x40);
	}
	/* Send Address to DDRAM of LCD */
	CLCD_voidSendCommand(L_u8Address+128);
}


void CLCD_voidSendCommand (u8 ARG_u8Command)
{
	/* Set RS_Pin LOW for Command */
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_RS_PIN, MDIO_LOW);
	/* Set RW_Pin LOW for Write */
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_RW_PIN, MDIO_LOW);

#if CLCD_MODE==0
	/* Send Command for Port */
	MDIO_voidSetPortValue(CLCD_DATAPORT, LSB_Signfication, ARG_u8Command);

	/* Enable E_Pin (Sending Pulse)*/
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_HIGH);

	MSTICK_voidBusyWait(2);

	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_LOW);

#elif CLCD_MODE==1
	/* Send The Last 4-bits of Command to Port */
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN4, (ARG_u8Command&(0x01<<4))>>4);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN5, (ARG_u8Command&(0x01<<5))>>5);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN6, (ARG_u8Command&(0x01<<6))>>6);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN7, (ARG_u8Command&(0x01<<7))>>7);
	/* Enable E_Pin (Sending Pulse)*/
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_HIGH);

	MSTICK_voidBusyWait(2);

	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_LOW);

	/* Send The First 4-bits of Command to Port */
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN4, (ARG_u8Command&(0x01<<0))>>0);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN5, (ARG_u8Command&(0x01<<1))>>1);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN6, (ARG_u8Command&(0x01<<2))>>2);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN7, (ARG_u8Command&(0x01<<3))>>3);
	/* Enable E_Pin (Sending Pulse)*/
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_HIGH);

	MSTICK_voidBusyWait(2);

	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_LOW);
#endif
}


void CLCD_voidSendData(u8 ARG_u8Data)
{
	/* Set RS_Pin HIGH for DATA */
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_RS_PIN, MDIO_HIGH);
	/* Set RW_Pin LOW for Write */
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_RW_PIN, MDIO_LOW);

#if CLCD_MODE==0
	/* Send DATA for Port */
	MDIO_voidSetPortValue(CLCD_DATAPORT, LSB_Signfication, ARG_u8Data);

	/* Enable E_Pin (Sending Pulse)*/
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_HIGH);

	MSTICK_voidBusyWait(2);

	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_LOW);

#elif CLCD_MODE==1
	/* Masking For The First 4-bits And KEEPING the RS_PIN Is HIGH */
	/* Send The Last 4-bits of DATA to Port */
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN4, (ARG_u8Data&(0x01<<4))>>4);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN5, (ARG_u8Data&(0x01<<5))>>5);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN6, (ARG_u8Data&(0x01<<6))>>6);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN7, (ARG_u8Data&(0x01<<7))>>7);
	/* Enable E_Pin (Sending Pulse)*/
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_HIGH);

	MSTICK_voidBusyWait(2);

	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_LOW);

	/* Masking For The Last 4-bits And KEEPING the RS_PIN Is HIGH */
	/* Send The First 4-bits of DATA to Port */
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN4, (ARG_u8Data&(0x01<<0))>>0);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN5, (ARG_u8Data&(0x01<<1))>>1);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN6, (ARG_u8Data&(0x01<<2))>>2);
	MDIO_voidSetPinValue(CLCD_DATAPORT, CLCD_DATAPIN7, (ARG_u8Data&(0x01<<3))>>3);
	/* Enable E_Pin (Sending Pulse)*/
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_HIGH);

	MSTICK_voidBusyWait(2);

	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_LOW);
#endif
}


void CLCD_voidSendDataXY(u8 ARG_Y, u8 ARG_X,u8 ARG_u8Character)
{
	/* Set Local Address For Location */
	u8 L_u8Address=0;

	if(0 == ARG_Y)
	{
		L_u8Address = ARG_X;
	}
	else if (1 == ARG_Y)
	{
		L_u8Address = (ARG_X+0x40);
	}
	/* Send Address to DDRAM of LCD */
	CLCD_voidSendCommand(L_u8Address+128);

	/* Set RS_Pin LOW for Data */
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_RS_PIN, MDIO_HIGH);
	/* Set RW_Pin LOW for Write */
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_RW_PIN, MDIO_LOW);

	/* Send Data for Port */
	MDIO_voidSetPortValue(CLCD_DATAPORT, LSB_Signfication, ARG_u8Character);

	/*  Enable E_Pin (Sending Pulse) */
	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_HIGH);

	MSTICK_voidBusyWait(2);

	MDIO_voidSetPinValue(CLCD_CTRLPORT, CLCD_E_PIN, MDIO_LOW);
}

void CLCD_voidSendString(const char *ARG_u8String)
{
	/* Set Local Counter For Characters in String */
	u8 L_u8Counter=0;

	/* Send Every Character */
	while('\0' != ARG_u8String[L_u8Counter])
	{
		CLCD_voidSendData(ARG_u8String[L_u8Counter]);
		L_u8Counter++;
	}
}


void CLCD_voidSendStringXY(u8 ARG_Y, u8 ARG_X, const char *ARG_u8String)
{
	/* Set Local Address For Location */
	u8 L_u8Address=0;
	/* Set Local Counter For Characters in String */
	u8 L_u8Counter=0;

	if(0 == ARG_Y)
	{
		L_u8Address = ARG_X;
	}
	else if (1 == ARG_Y)
	{
		L_u8Address = (ARG_X+0x40);
	}
	/* Send Address to DDRAM of LCD */
	CLCD_voidSendCommand(L_u8Address+128);

	/* Send Every Character */
	while('\0' != ARG_u8String[L_u8Counter])
	{
		CLCD_voidSendData(ARG_u8String[L_u8Counter]);
		L_u8Counter++;
	}
}


void CLCD_voidSendSpecialCharacter(u8 *ARG_u8Pattern, u8 ARG_u8CGRBlockNumber, u8 ARG_Y, u8 ARG_X)
{
	u8 L_u8CGRAdderess=0,L_u8Iteration;
	/* Calculate The CGRAM_Address whose each Address is 8 bytes */
	L_u8CGRAdderess = ARG_u8CGRBlockNumber*8;

	/* Send Address Command to LCD, with setting bit 6, clearing bit 7 */
	CLCD_voidSendCommand(L_u8CGRAdderess+64);

	/* Write Pattern in CGRAM */
	for(L_u8Iteration=0; L_u8Iteration<8; L_u8Iteration++)
	{
		CLCD_voidSendData(ARG_u8Pattern[L_u8Iteration]);
	}

	/*Go Back to DDRAM And Display */
	CLCD_voidSendDataXY(ARG_Y, ARG_X, ARG_u8CGRBlockNumber);

}


void CLCD_voidWriteNumber(f32 ARG_f32Num)
{
	/* Create counter and Copy of the Number */
	s8 L_s8counter=0, L_s8StartPos=0, L_s8iteration,L_s8Negative=0,L_s8Float=0, L_s8Size=0;
	u32 L_u32copy_Num;


	/*Check if The Number is Negative */
	if(ARG_f32Num<0)
	{
		L_s8Negative=1;
		ARG_f32Num*=(-1);
	}

	/* Trick to Check if The Number If Float */
	L_u32copy_Num=ARG_f32Num;

	if(L_u32copy_Num<ARG_f32Num)
	{
		ARG_f32Num*=1000;
		L_s8Float=1;
	}
	L_u32copy_Num=ARG_f32Num;

	/* Count the Digits in The Number */
	do
	{
		L_u32copy_Num/=10;
		++L_s8counter;

	}while(L_u32copy_Num!=0);

	L_u32copy_Num=ARG_f32Num;

	/* Check the Case To Set The Loops Initialization */
	if(1==L_s8Float)
	{
		L_s8StartPos=L_s8counter;
		L_s8Size=L_s8counter+1;
		L_s8counter+=1;
	}
	else
	{
		L_s8StartPos=L_s8counter-1;
		L_s8Size=L_s8counter;

	}

	/* Create Array to Store The Digits */
	s8 Array[L_s8Size];

	/* Store The Digits in Reverse */
	for(L_s8iteration=0; L_s8iteration<L_s8Size; L_s8iteration++)
	{
		Array[L_s8StartPos]=(L_u32copy_Num%10);
		/* Push The Dot In Its Place Of The Array */
		if(1==L_s8Float&&2==L_s8iteration)
		{
			L_s8StartPos--;
			Array[L_s8StartPos]='.';
			L_s8Float=0;
		}
		L_u32copy_Num=(L_u32copy_Num/10);
		L_s8StartPos--;
	}
	if(1==L_s8Negative)
		CLCD_voidSendData('-');
	/*Sending Array Ascii_Values(Digits of the Number) To LCD */
	for(L_s8iteration=0; L_s8iteration<L_s8Size; L_s8iteration++)
	{
		/* Print The Dot In Its Place */
		if('.'==Array[L_s8iteration])
			CLCD_voidSendData('.');
		else
			CLCD_voidSendData('0'+Array[L_s8iteration]);
	}

}

void CLCD_voidShift(u8 ARG_u8Direction)
{
	/*Check if Shift Cursor Left */
	if(Shift_CursorLeft == ARG_u8Direction)
		CLCD_voidSendCommand(0x10);

	/*Check if Shift Cursor Right */
	if(Shift_CursorRight == ARG_u8Direction)
		CLCD_voidSendCommand(0x14);
	/*Check if Shift Display Left */
	if(Shift_DisplayLeft == ARG_u8Direction)
		CLCD_voidSendCommand(0x18);

	/*Check if Shift Display Right */
	if(Shift_DisplayRight == ARG_u8Direction)
		CLCD_voidSendCommand(0x1C);

}
