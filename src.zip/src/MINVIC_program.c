/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: INVIC    				*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#include "LSTD_types.h"
#include "LBIT_math.h"
#include "MINVIC_config.h"
#include "MINVIC_private.h"
#include "MINVIC_interface.h"

void MINVIC_voidInit(void)
{
	#define SCB_AIRCR	*((u32 *)0xE000ED0C)
	SCB_AIRCR = GROUP_SUB_DIS;
}

void MINVIC_voidSetPriority(u8 Copy_u8InterruptID, u8 Copy_u8Priority)
{
	if(59>=Copy_u8InterruptID)
	{
		MINVIC_IPR[Copy_u8InterruptID] = Copy_u8Priority;
	}
	else
	{
		
	}
}

void MINVIC_voidEnableInterrupt(u8 Copy_u8InterruptID)
{
	
	if(31 >= Copy_u8InterruptID)
	{
		MNVIC_ISER0 = 1<<Copy_u8InterruptID;
	}
	else if(59 >= Copy_u8InterruptID)
	{
		Copy_u8InterruptID -= 32;
		MNVIC_ISER1 = 1<<Copy_u8InterruptID;
	}
	else
	{
		
	}	
}

void MINVIC_voidDisableInterrupt(u8 Copy_u8InterruptID)
{
	
	if(31 >= Copy_u8InterruptID)
	{
		MNVIC_ICER0 = 1<<Copy_u8InterruptID;
	}
	else if(59 >= Copy_u8InterruptID)
	{
		Copy_u8InterruptID -= 32;
		MNVIC_ICER1 = 1<<Copy_u8InterruptID;
	}
	else
	{
		
	}	
}

void MINVIC_voidSetPindingFlag(u8 Copy_u8InterruptID)
{
	
	if(31 >= Copy_u8InterruptID)
	{
		MNVIC_ISPR0 = 1<<Copy_u8InterruptID;
	}
	else if(59 >= Copy_u8InterruptID)
	{
		Copy_u8InterruptID -= 32;
		MNVIC_ISPR1 = 1<<Copy_u8InterruptID;
	}
	else
	{
		
	}	
}

void MINVIC_voidClearPindingFlag(u8 Copy_u8InterruptID)
{
	
	if(31 >= Copy_u8InterruptID)
	{
		MNVIC_ICPR0 = 1<<Copy_u8InterruptID;
	}
	else if(59 >= Copy_u8InterruptID)
	{
		Copy_u8InterruptID -= 32;
		MNVIC_ICPR1 = 1<<Copy_u8InterruptID;
	}
	else
	{
		
	}	
}

u8 MINVIC_u8GetActiveFlag(u8 Copy_u8InterruptID)
{
	u8 Loc_u8Var=0;
	
	if(31 >= Copy_u8InterruptID)
	{
		Loc_u8Var = GET_BIT(MNVIC_IABR0,Copy_u8InterruptID);
	}
	else if(59 >= Copy_u8InterruptID)
	{
		Copy_u8InterruptID -= 32;
		Loc_u8Var = GET_BIT(MNVIC_IABR1,Copy_u8InterruptID);
	}
	else
	{
		
	}
	return 	Loc_u8Var;
}
