/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: SYSTICK    				*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#include "LSTD_types.h"
#include "LBIT_math.h"
#include "MSTICK_config.h"
#include "MSTICK_private.h"
#include "MSTICK_interface.h"

static void(*pfCallBack)(void)=NULL;
static u8 Glo_u8Periodicity = 0;

void MSTICK_voidInit(void)
{
	#if MSTICK_CLOCK_SOURCE == MSTICK_CLK_AHB_DIV8
	SET_BIT(MSTICK_CTRL, 2);
	#elif MSTICK_CLOCK_SOURCE == MSTICK_CLK_AHB
	CLEAR_BIT(MSTICK_CTRL, 2);
	#else
		#error ("ERROR")
	#endif
}

void MSTICK_voidStart(void)
{
	SET_BIT(MSTICK_CTRL, 0);

}

void MSTICK_voidStop(void)
{
	CLEAR_BIT(MSTICK_CTRL, 0);
}

void MSTICK_voidBusyWait(u16 Copy_u16MillSec)
{
	MSTICK_LOAD = Copy_u16MillSec*1000;
	SET_BIT(MSTICK_CTRL, 0);
	while(!GET_BIT(MSTICK_CTRL, 16));
}

void MSTICK_voidIntervalSingle(u16 Copy_u16MillSec, void(*pfUserFun)(void))
{
	CLEAR_BIT(MSTICK_CTRL, 0);
	MSTICK_VAL = 0;

	Glo_u8Periodicity = 0;
	pfCallBack = pfUserFun;
	MSTICK_LOAD = (Copy_u16MillSec*1000);
	SET_BIT(MSTICK_CTRL, 1);
	SET_BIT(MSTICK_CTRL, 0);

}
void MSTICK_voidIntervalPeriodic(u16 Copy_u16MillSec, void(*pfUserFun)(void))
{
	CLEAR_BIT(MSTICK_CTRL, 0);
	MSTICK_VAL = 0;

	Glo_u8Periodicity = 1;
	pfCallBack = pfUserFun;
	MSTICK_LOAD = Copy_u16MillSec*1000;
	SET_BIT(MSTICK_CTRL, 1);
	SET_BIT(MSTICK_CTRL, 0);
}

u32 MSTICK_u32GetElapsedTime(void)
{
	return (MSTICK_LOAD - MSTICK_VAL);
}

u32 MSTICK_u32GetRemainingTime(void)
{
	return (MSTICK_VAL);
}

void SysTick_Handler(void)
{
	pfCallBack();

	if(0 == Glo_u8Periodicity)
	{
		MSTICK_LOAD = 0;
		MSTICK_VAL = 0;
	}

}
