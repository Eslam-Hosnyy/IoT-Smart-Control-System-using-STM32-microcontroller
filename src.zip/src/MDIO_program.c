/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: DIO     				*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#include "LSTD_types.h"
#include "LBIT_math.h"
#include "MDIO_private.h"
#include "MDIO_interface.h"

void MDIO_voidSetPinMode(u8 Copy_u8Port, u8 Copy_u8Pin, u8 Copy_u8Mode)
{
	if(15 >= Copy_u8Pin)
	{
		switch(Copy_u8Port)
		{
		case MDIOA :{
			if(7 >= Copy_u8Pin)
			{
				MDIOA_CRL &= ~((0b1111)<<(Copy_u8Pin*4));
				MDIOA_CRL |= ((Copy_u8Mode)<<(Copy_u8Pin*4));
			}
			else if(15 > Copy_u8Pin)
			{
				Copy_u8Pin-=8;
				MDIOA_CRH &= ~((0b1111)<<(Copy_u8Pin*4));
				MDIOA_CRH |= ((Copy_u8Mode)<<(Copy_u8Pin*4));
			}
			break;
		}
		case MDIOB :{
			if(7 >= Copy_u8Pin)
			{
				MDIOB_CRL &= ~((0b1111)<<(Copy_u8Pin*4));
				MDIOB_CRL |= ((Copy_u8Mode)<<(Copy_u8Pin*4));
			}
			else if(15 > Copy_u8Pin)
			{
				Copy_u8Pin-=8;
				MDIOB_CRH &= ~((0b1111)<<(Copy_u8Pin*4));
				MDIOB_CRH |= ((Copy_u8Mode)<<(Copy_u8Pin*4));
			}
			break;
		}
		case MDIOC :{
			if(7 >= Copy_u8Pin)
			{
				MDIOC_CRL &= ~((0b1111)<<(Copy_u8Pin*4));
				MDIOC_CRL |= ((Copy_u8Mode)<<(Copy_u8Pin*4));
			}
			else if(15 > Copy_u8Pin)
			{
				Copy_u8Pin-=8;
				MDIOC_CRH &= ~((0b1111)<<(Copy_u8Pin*4));
				MDIOC_CRH |= ((Copy_u8Mode)<<(Copy_u8Pin*4));
			}
			break;
		}
		default : /* Invalid PORT */ break;
		}
	}

}

void MDIO_voidSetPortMode(u8 Copy_u8Port, u8 Copy_u8Signfication, u8 Copy_u8Mode)
{
	static u8 i;
	if(LSB_Signfication == Copy_u8Signfication)
	{
		switch(Copy_u8Port)
		{
		case MDIOA :{
			for(i=0; i<8; i++)
			{
				MDIOA_CRL &= ~((0b1111)<<(i*4));
				MDIOA_CRL |= ((Copy_u8Mode)<<(i*4));
			}
			break;
		}
		case MDIOB :{
			for(i=0; i<8; i++)
			{
				MDIOB_CRL &= ~((0b1111)<<(i*4));
				MDIOB_CRL |= ((Copy_u8Mode)<<(i*4));
			}
			break;
		}
		case MDIOC :{
			for(i=0; i<8; i++)
			{
				MDIOC_CRL &= ~((0b1111)<<(i*4));
				MDIOC_CRL |= ((Copy_u8Mode)<<(i*4));
			}
			break;
		}
		default : /* Invalid PORT */ break;
		}
	}
	else if(MSB_Signfication == Copy_u8Signfication)
	{
		switch(Copy_u8Port)
		{
		case MDIOA :{
			for(i=0; i<8; i++)
			{
				MDIOA_CRH &= ~((0b1111)<<(i*4));
				MDIOA_CRH |= ((Copy_u8Mode)<<(i*4));
			}
			break;
		}
		case MDIOB :{
			for(i=0; i<8; i++)
			{
				MDIOB_CRH &= ~((0b1111)<<(i*4));
				MDIOB_CRH |= ((Copy_u8Mode)<<(i*4));
			}
			break;
		}
		case MDIOC :{
			for(i=0; i<8; i++)
			{
				MDIOC_CRH &= ~((0b1111)<<(i*4));
				MDIOC_CRH |= ((Copy_u8Mode)<<(i*4));
			}
			break;
		}
		default : /* Invalid PORT */ break;
		}
	}

}


void MDIO_voidSetPinValue(u8 Copy_u8Port, u8 Copy_u8Pin, u8 Copy_u8value)
{
	if (15 >= Copy_u8Pin)
	{
		switch(Copy_u8Port)
		{
		case MDIOA:{
			if(MDIO_HIGH==Copy_u8value)
				SET_BIT(MDIOA_ODR,Copy_u8Pin);
			else if(MDIO_LOW==Copy_u8value)
				CLEAR_BIT(MDIOA_ODR,Copy_u8Pin);
			else {}/*Invalid Value */
			break;
		}
		case MDIOB:{
			if(MDIO_HIGH==Copy_u8value)
				SET_BIT(MDIOB_ODR,Copy_u8Pin);
			else if(MDIO_LOW==Copy_u8value)
				CLEAR_BIT(MDIOB_ODR,Copy_u8Pin);
			else {}/*Invalid Value */
			break;
		}
		case MDIOC:{
			if(MDIO_HIGH==Copy_u8value)
				SET_BIT(MDIOC_ODR,Copy_u8Pin);
			else if(MDIO_LOW==Copy_u8value)
				CLEAR_BIT(MDIOC_ODR,Copy_u8Pin);
			else {}/*Invalid Value */
			break;
		}
		default : /* Invalid*/ break;
		}
	}
	else
	{
		/*Invalid PIN Number */
	}

}

void MDIO_voidSetPortValue(u8 Copy_u8Port, u8 Copy_u8Signfication, u8 Copy_u8value)
{
	if(LSB_Signfication == Copy_u8Signfication)
	{
		switch(Copy_u8Port)
		{
		case MDIOA:{
			MDIOA_ODR &= 0x0000FF00;
			MDIOA_ODR |= (0x00000000+Copy_u8value);
			break;
		}
		case MDIOB:{
			MDIOB_ODR &= 0x0000FF00;
			MDIOB_ODR |= (0x00000000+Copy_u8value);
			break;
		}
		case MDIOC:{
			MDIOC_ODR &= 0x0000FF00;
			MDIOC_ODR |= (0x00000000+Copy_u8value);
			break;
		}
		default : /* Invalid*/ break;
		}
	}
	else if(MSB_Signfication == Copy_u8Signfication)

	{
		switch(Copy_u8Port)
		{
		case MDIOA:{
			MDIOA_ODR &= 0x000000FF;
			MDIOA_ODR |= (0x00000000+Copy_u8value)<<8;
			break;
		}
		case MDIOB:{
			MDIOB_ODR &= 0x000000FF;
			MDIOB_ODR |= (0x00000000+Copy_u8value)<<8;
			break;
		}
		case MDIOC:{
			MDIOC_ODR &= 0x000000FF;
			MDIOC_ODR |= (0x00000000+Copy_u8value)<<8;
			break;
		}
		default : /* Invalid*/ break;
		}
	}
	else
	{
		
	}

}

u8 MDIO_voidGetPinValue(u8 Copy_u8Port, u8 Copy_u8Pin)
{
	u8 Copy_u8Value=0;
	if (15 >= Copy_u8Pin)
	{
		switch(Copy_u8Port)
		{
		case MDIOA:{
			Copy_u8Value = GET_BIT(MDIOA_IDR,Copy_u8Pin);
			break;
		}
		case MDIOB:{
			Copy_u8Value = GET_BIT(MDIOB_IDR,Copy_u8Pin);
			break;
		}
		case MDIOC:{
			Copy_u8Value = GET_BIT(MDIOC_IDR,Copy_u8Pin);
			break;
		}
		default : /* Invalid*/ break;
		}
	}
	else
	{
		/*Invalid PIN Number */
	}

	return Copy_u8Value;
}


void MDIO_voidBSRR_Set_Clear_Pin(u8 Copy_u8Port, u8 Copy_u8Pin, u8 Copy_u8value)
{
	if (15 >= Copy_u8Pin)
	{
		switch(Copy_u8Port)
		{
		case MDIOA:{
			if(MDIO_HIGH==Copy_u8value)
			{
				MDIOA_BSRR = 1<<Copy_u8Pin;
			}
			else if(MDIO_LOW==Copy_u8value)
			{
				MDIOA_BSRR = 1<<(Copy_u8Pin+16);
			}
			else {
			}/*Invalid Value */
			break;
		}
		case MDIOB:{
			if(MDIO_HIGH==Copy_u8value)
			{
				MDIOB_BSRR = 1<<Copy_u8Pin;
			}
			else if(MDIO_LOW==Copy_u8value)
			{
				MDIOB_BSRR = 1<<(Copy_u8Pin+16);
			}
			else {

			}/*Invalid Value */
			break;
		}
		case MDIOC:{
			if(MDIO_HIGH==Copy_u8value)
			{
				MDIOC_BSRR = 1<<Copy_u8Pin;
			}
			else if(MDIO_LOW==Copy_u8value)
			{
				MDIOC_BSRR = 1<<(Copy_u8Pin+16);
			}
			else {

			}/*Invalid Value */
			break;
		}
		default : /* Invalid*/ break;
		}
	}
	else
	{
		/*Invalid PIN Number */
	}

}


void MDIO_voidBRR_Clear_Pin(u8 Copy_u8Port, u8 Copy_u8Pin)
{
	if (15 >= Copy_u8Pin)
	{
		switch(Copy_u8Port)
		{
		case MDIOA:{
			MDIOA_BRR = 1<<Copy_u8Pin;
			break;
		}
		case MDIOB:{
			MDIOA_BRR = 1<<Copy_u8Pin;
			break;
		}
		case MDIOC:{
			MDIOA_BRR = 1<<Copy_u8Pin;
			break;
		}
		default : /* Invalid*/ break;
		}
	}
	else
	{
		/*Invalid PIN Number */
	}

}
