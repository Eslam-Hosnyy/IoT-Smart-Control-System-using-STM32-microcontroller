/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: SYSTICK     			*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MSTICK_INTERFACE_H_
#define	_MSTICK_INTERFACE_H_
	

void MSTICK_voidInit(void);

void MSTICK_voidStart(void);

void MSTICK_voidStop(void);

void MSTICK_voidBusyWait(u16 Copy_u16MillSec);

void MSTICK_voidIntervalSingle(u16 Copy_u16MillSec, void(*pUserFun)(void));

void MSTICK_voidIntervalPeriodic(u16 Copy_u16MillSec, void(*pUserFun)(void));

u32 MSTICK_u32GetElapsedTime(void);

u32 MSTICK_u32GetRemainingTime(void);


#endif
