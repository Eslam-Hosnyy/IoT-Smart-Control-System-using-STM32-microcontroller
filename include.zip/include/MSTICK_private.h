/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: SYSTICK     			*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MSTICK_PRIVATE_H_
#define	_MSTICK_PRIVATE_H_


/* MSYSTICK Base Addresses */
#define	MSTICK_BASE_ADDRESS			0xE000E010

/* MSYSTICK Registers */
#define MSTICK_CTRL					*((volatile u32 *)(MSTICK_BASE_ADDRESS+0x00))
#define MSTICK_LOAD					*((volatile u32 *)(MSTICK_BASE_ADDRESS+0x04))
#define MSTICK_VAL					*((volatile u32 *)(MSTICK_BASE_ADDRESS+0x08))
#define MSTICK_CALIB				*((volatile u32 *)(MSTICK_BASE_ADDRESS+0x0C))


#define MSTICK_CLK_AHB					1
#define MSTICK_CLK_AHB_DIV8				0


#endif
