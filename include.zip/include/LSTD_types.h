/****************************************/
/*	Author		:	Eslam_Hosny			*/
/*	SWC			:	Standard Types		*/
/*	Layer		:	LIB					*/
/*	Version		:	1.1					*/
/*	Date		:	September  9, 2022	*/
/*	Last Edit	:	October    9, 2022	*/
/****************************************/

#ifndef	_LSTD_TYPES_H_
#define	_LSTD_TYPES_H_

/* Macros OF Errors */
typedef enum{
	NULL = 0,
	NULL_POINTER,
	MDIO_OK,
	MDIO_NOK,
	MADC_OK,
	MADC_NOK,
	MADC_BUSY,
	OPSystem_OK,
	OPSystem_NOK,
	MTWI_OK,
	MTWI_INVALID_ADDRESS,
	MTWI_SC_ERROR,
	MTWI_RSC_ERROR,
	MTWI_SEND_SLA_W_ERROR,
	MTWI_SEND_SLA_R_ERROR,
	MTWI_SEND_SLA_RW_INVALID,
	MTWI_SEND_DATA_ERROR,
	MTWI_READ_DATA_ERROR,
	MTWI_ACK_STATE_INVALID,
	EEPROM_OK,

}ErrorState;


typedef unsigned char 			u8;
typedef unsigned short int 		u16;
typedef unsigned long int 		u32;
typedef unsigned long long 		u46;
typedef signed char		 		s8;
typedef signed short int 		s16;
typedef signed long int 		s32;
typedef signed long long 		s64;
typedef float					f16;
typedef double					f32;


#endif
