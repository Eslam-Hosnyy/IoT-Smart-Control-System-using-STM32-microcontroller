/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: RCC     				*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MRCC_INTERFACE_H_
#define	_MRCC_INTERFACE_H_

/* Prephirals_Buses */
#define MRCC_AHB_BUS		1
#define MRCC_APB1_BUS		2
#define MRCC_APB2_BUS		3
/* System Clock Source */
#define MRCC_HSE_CRYSTAL	1
#define MRCC_HSE_RC			2
#define MRCC_HSI			3
#define MRCC_PLL			4
/* PLL_Clock Source */
#define MRCC_PLL_HSE			1
#define MRCC_PLL_HSE_DIV_2		2
#define MRCC_PLL_HSI_DIV_2		3

void MRCC_voidEnablePrephiralClock(u8 Copy_u8Bus, u8 Copy_u8PrephiralId);

void MRCC_voidDisablePrephiralClock(u8 Copy_u8Bus, u8 Copy_u8PrephiralId);

void MRCC_voidInitSystemClock(void);







#endif
