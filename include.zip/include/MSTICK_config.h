/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: SYSTICCK     			*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MSTICK_CONFIG_H_
#define	_MSTICK_CONFIG_H_

/* Options of Clock Source :
						- MSTICK_CLK_AHB
						- MSTICK_CLK_AHB_DIV8     */					
#define MSTICK_CLOCK_SOURCE		MSTICK_CLK_AHB_DIV8


#endif
