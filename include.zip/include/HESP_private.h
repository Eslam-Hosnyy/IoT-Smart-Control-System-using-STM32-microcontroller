/************************************/
/*	Author		: ESLAM_HOSNY		*/
/*	SWC			: ESP8266		 	*/
/*	Layer		: HAL				*/
/*	Version   	: 1.0				*/
/*	Date	  	: October 23, 2022	*/
/*	Last Edit 	: N/A				*/
/************************************/
#ifndef	_HESP_PRIVATE_H_
#define	_HESP_PRIVATE_H_


static u8 HESP_u8Validation(void);

static void Concatenate(char *S1, char *S2, char *S3);


#endif
