/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: USART	    			*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MUSART_INTERFACE_H_
#define	_MUSART_INTERFACE_H_

#define MUSART_BAUD_RATE_9600		9600
#define MUSART_BAUD_RATE_115200		115200

#define MUSART_DATABITS_8			0
#define MUSART_DATABITS_9			1

#define MUSART_NO_PARITY			00
#define MUSART_EVEN_PARITY			10
#define MUSART_ODD_PARITY			11

#define MUSART_STOPBITS_1			00
#define MUSART_STOPBITS_2			10


void MUSART_voidInit(u8 Copy_u8DataSize, u8 Copy_u8StopBits, u8 Copy_u8Parity, u32 Copy_u32BaudRate);

void MUSART_voidEnable(void);

void MUSART_voidDisable(void);

void MUSART_voidTransimitSynch(const char *Copy_charData);

void MUSART_voidTransimitASynch(char *Ptr_charTxData);

void MUSART_voidReceiveSynch(char *ptr_charRecievedData, char Copy_charTreminator);

void MUSART_voidReceiveASynch(char *Ptr_charRxData);

#endif
