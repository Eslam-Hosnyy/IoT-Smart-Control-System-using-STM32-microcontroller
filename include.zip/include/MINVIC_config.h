/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: INVIC     			*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MINVIC_CONFIG_H_
#define	_MINVIC_CONFIG_H_

/* Options of Group_Sub_Priority
*  GROUP_4_SUB_0	
*  GROUP_3_SUB_1       
*  GROUP_2_SUB_2       
*  GROUP_1_SUB_3       
*  GROUP_0_SUB_4	
				*/
#define GROUP_SUB_DIS	GROUP_2_SUB_2


#endif
