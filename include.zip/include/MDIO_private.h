/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: DIO     				*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MDIO_PRIVATE_H_
#define	_MDIO_PRIVATE_H_


/* MDIO Global Base Addresses */
#define	MDIOA_BASE_ADDRESS		0x40010800
#define	MDIOB_BASE_ADDRESS		0x40010C00
#define	MDIOC_BASE_ADDRESS		0x40011000
/* PORTA Registers */
#define	MDIOA_CRL				*((u32 *)(MDIOA_BASE_ADDRESS+0x00))
#define	MDIOA_CRH				*((u32 *)(MDIOA_BASE_ADDRESS+0x04))
#define	MDIOA_IDR				*((u32 *)(MDIOA_BASE_ADDRESS+0x08))
#define	MDIOA_ODR				*((u32 *)(MDIOA_BASE_ADDRESS+0x0C))
#define	MDIOA_BSRR				*((u32 *)(MDIOA_BASE_ADDRESS+0x10))
#define	MDIOA_BRR				*((u32 *)(MDIOA_BASE_ADDRESS+0x14))
#define	MDIOA_LCKR				*((u32 *)(MDIOA_BASE_ADDRESS+0x18))
/* PORTB Registers */
#define	MDIOB_CRL				*((u32 *)(MDIOB_BASE_ADDRESS+0x00))
#define	MDIOB_CRH				*((u32 *)(MDIOB_BASE_ADDRESS+0x04))
#define	MDIOB_IDR				*((u32 *)(MDIOB_BASE_ADDRESS+0x08))
#define	MDIOB_ODR				*((u32 *)(MDIOB_BASE_ADDRESS+0x0C))
#define	MDIOB_BSRR				*((u32 *)(MDIOB_BASE_ADDRESS+0x10))
#define	MDIOB_BRR				*((u32 *)(MDIOB_BASE_ADDRESS+0x14))
#define	MDIOB_LCKR				*((u32 *)(MDIOB_BASE_ADDRESS+0x18))
/* PORTC Registers */
#define	MDIOC_CRL				*((u32 *)(MDIOC_BASE_ADDRESS+0x00))
#define	MDIOC_CRH				*((u32 *)(MDIOC_BASE_ADDRESS+0x04))
#define	MDIOC_IDR				*((u32 *)(MDIOC_BASE_ADDRESS+0x08))
#define	MDIOC_ODR				*((u32 *)(MDIOC_BASE_ADDRESS+0x0C))
#define	MDIOC_BSRR				*((u32 *)(MDIOC_BASE_ADDRESS+0x10))
#define	MDIOC_BRR				*((u32 *)(MDIOC_BASE_ADDRESS+0x14))
#define	MDIOC_LCKR				*((u32 *)(MDIOC_BASE_ADDRESS+0x18))

#endif
