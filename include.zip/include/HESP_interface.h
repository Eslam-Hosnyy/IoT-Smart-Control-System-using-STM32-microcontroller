/************************************/
/*	Author		: ESLAM_HOSNY		*/
/*	SWC			: ESP8266		 	*/
/*	Layer		: HAL				*/
/*	Version   	: 1.0				*/
/*	Date	  	: October 23, 2022	*/
/*	Last Edit 	: N/A				*/
/************************************/
#ifndef	_HESP_INTERFACE_H_
#define	_HESP_INTERFACE_H_

void HESP_voidInit(void);

void HESP_voidConnectToNetWork(char *Ptr_charUser, char *Ptr_charPass);

void HESP_voidConnectToServer(char *Ptr_CharConnType, char *Ptr_charIP,char *Ptr_chaPort);

void HESP_voidSendLength(char *ptr_charLinkLength);

void HESP_u8GetDataLink(char *ptr_charLink, char *ptr_charReturnedData);


#endif
