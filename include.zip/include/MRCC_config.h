/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: RCC     				*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MRCC_CONFIG_H_
#define	_MRCC_CONFIG_H_

/* 4-options For System Clock Source :
								-MRCC_HSE_CRYSTAL
								-MRCC_HSE_RC
								-MRCC_HSI
								-MRCC_PLL	*/
#define MRCC_SYSTEM_CLCK	MRCC_HSE_CRYSTAL
/* 3-options For PLL_Input :
							-MRCC_PLL_HSE
							-MRCC_PLL_HSE_DIV_2
							-MRCC_PLL_HSI_DIV_2	*/
#define	PLL_INPUT_SOURCE	MRCC_PLL_HSI_DIV_2
/* PLL Multiplication Factor:
							2:16			*/
#define PLL_MUL_FACTOR		4



#endif
