/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: INVIC    				*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MINVIC_INTERFACE_H_
#define	_MINVIC_INTERFACE_H_


/* ALL External Interrupts_ID of STM32f10x  */
#define MINVIC_WWDG					0
#define MINVIC_PVD					1
#define MINVIC_TAMPER				2
#define MINVIC_RTC					3
#define MINVIC_FLASH				4
#define MINVIC_RCC					5
#define MINVIC_EXTI0				6
#define MINVIC_EXTI1				7
#define MINVIC_EXTI2				8
#define MINVIC_EXTI3				9
#define MINVIC_EXTI4				10
#define MINVIC_DMA1_CHANNEL1		11
#define MINVIC_DMA1_CHANNEL2		12
#define MINVIC_DMA1_CHANNEL3		13
#define MINVIC_DMA1_CHANNEL4		14
#define MINVIC_DMA1_CHANNEL5		15
#define MINVIC_DMA1_CHANNEL6		16
#define MINVIC_DMA1_CHANNEL7		17
#define MINVIC_ADC1_2				18
#define MINVIC_USB_HP_CAN_TX		19
#define MINVIC_USB_HP_CAN_RX0		20
#define MINVIC_CAN_RX1				21
#define MINVIC_CAN_SCE				22
#define MINVIC_EXTI9_5				23
#define MINVIC_TIM1_BRK				24
#define MINVIC_TIM1_UP				25
#define MINVIC_TIM1_TRG_COM			26
#define MINVIC_TIM1_CC				27
#define MINVIC_TIM2					28
#define MINVIC_TIM3					29
#define MINVIC_TIM4					30
#define MINVIC_I2C1_EV				31
#define MINVIC_I2C1_ER				32
#define MINVIC_I2C2_EV				33
#define MINVIC_I2C2_ER				34
#define MINVIC_SPI1					35
#define MINVIC_SPI2					36
#define MINVIC_USART1				37
#define MINVIC_USART2				38
#define MINVIC_USART3				39
#define MINVIC_EXTI15_10			40
#define MINVIC_RTCALARM				41
#define MINVIC_USBWakeup			42
#define MINVIC_TIM8_BRK				43
#define MINVIC_TIM8_UP				44
#define MINVIC_TIM8_TRG_COM			45
#define MINVIC_TIM8_CC				46
#define MINVIC_ADC3					47
#define MINVIC_FSMC					48
#define MINVIC_SDIO					49
#define MINVIC_TIM5					50
#define MINVIC_SPI3					51
#define MINVIC_UART4				52
#define MINVIC_UART5				53
#define MINVIC_TIM6					54
#define MINVIC_TIM7					55
#define MINVIC_DMA2_CHAANNEL1		56
#define MINVIC_DMA2_CHAANNEL2		57
#define MINVIC_DMA2_CHAANNEL3		58
#define MINVIC_DMA2_CHAANNEL4_5		59


void MINVIC_voidInit(void);
void MINVIC_voidSetPriority(u8 Copy_u8InterruptID, u8 Copy_u8Priority);

void MINVIC_voidEnableInterrupt(u8 Copy_u8InterruptID);
void MINVIC_voidDisableInterrupt(u8 Copy_u8InterruptID);

void MINVIC_voidSetPindingFlag(u8 Copy_u8InterruptID);
void MINVIC_voidClearPindingFlag(u8 Copy_u8InterruptID);

u8 MINVIC_u8GetActiveFlag(u8 Copy_u8InterruptID);


#endif
