/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: USART	     			*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MUSART_PRIVATE_H_
#define	_MUSART_PRIVATE_H_

typedef struct{

volatile u32 SR		;
volatile u32 DR		;
volatile u32 BBR	;
volatile u32 CR1	;
volatile u32 CR2	;
volatile u32 CR3	;
volatile u32 GTPR	;

}USART_Registers;

#define MUSART		((USART_Registers*)0x40013800)

static void MUSART_voidBrake(void);


#endif
