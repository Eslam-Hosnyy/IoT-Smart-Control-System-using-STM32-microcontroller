/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: USART	     			*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MUSART_CONFIG_H_
#define	_MUSART_CONFIG_H_


#define MUSART_SYSTEM_CLOCK		8000000

#endif
