/****************************************/
/*	Author		: ESLAM_HOSNY			*/
/*	SWC			: INVIC     			*/
/*	Layer		: MCAL					*/
/*	Version   	: 1.0					*/
/*	Date	  	: March 14, 2023		*/
/*	Last Edit 	: N/A					*/
/****************************************/
#ifndef	_MINVIC_PRIVATE_H_
#define	_MINVIC_PRIVATE_H_


/* MINVIC Base Addresses */
#define	MINVIC_BASE_ADDRESS		0xE000E100

/* MINVIC Registers */
#define MNVIC_ISER0				*((u32 *)(MINVIC_BASE_ADDRESS+0x000))
#define MNVIC_ISER1				*((u32 *)(MINVIC_BASE_ADDRESS+0x004))

#define MNVIC_ICER0				*((u32 *)(MINVIC_BASE_ADDRESS+0x080))
#define MNVIC_ICER1				*((u32 *)(MINVIC_BASE_ADDRESS+0x084))

#define MNVIC_ISPR0				*((u32 *)(MINVIC_BASE_ADDRESS+0x100))
#define MNVIC_ISPR1				*((u32 *)(MINVIC_BASE_ADDRESS+0x104))

#define MNVIC_ICPR0				*((u32 *)(MINVIC_BASE_ADDRESS+0x180))
#define MNVIC_ICPR1				*((u32 *)(MINVIC_BASE_ADDRESS+0x184))

#define MNVIC_IABR0				*((u32 *)(MINVIC_BASE_ADDRESS+0x200))
#define MNVIC_IABR1				*((u32 *)(MINVIC_BASE_ADDRESS+0x204))

#define MINVIC_IPR				((u8 *)(MINVIC_BASE_ADDRESS+0x300))

#define GROUP_4_SUB_0			0x5FA0300
#define GROUP_3_SUB_1           0x5FA0400
#define GROUP_2_SUB_2           0x5FA0500
#define GROUP_1_SUB_3           0x5FA0600
#define GROUP_0_SUB_4			0x5FA0700

#endif
